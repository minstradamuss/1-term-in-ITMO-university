module ru.covariance.dc21sample {
    requires commons.math3;

    opens ru.covariance.dc21sample;
}